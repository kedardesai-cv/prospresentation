// ═══════════════════════════════════════════════════════════════════════════
// CV Prospect Builder — MVP CONFIG
// Baseline demo = end-to-end spine only. Nice-to-have modules are OFF here.
// Flip a flag to true to re-enable a module. See ../docs/PRD.md for the
// baseline vs nice-to-have decision record (2026-07-02).
// ═══════════════════════════════════════════════════════════════════════════
window.FEATURES = {

  // ── AI ──────────────────────────────────────────────────────────────────
  liveAI: false,              // false = canned responses (demo never breaks
                              // in a meeting). Entering an API key via the
                              // key indicator switches to live calls.

  // ── Intake / Upload nice-to-haves ──────────────────────────────────────
  transcriptUpload: false,    // second drop zone for meeting transcripts
  selfDirectedPanel: false,   // self-directed account detect/confirm flow
  manualClassification: false,// asset class/subtype/notes classify flow

  // ── Analysis nice-to-haves ─────────────────────────────────────────────
  thinkingAnimation: false,   // animated "AI thinking" display
  narrativeGeneration: false, // per-topic narrative drafting + toggle
  askAI: false,               // ask-AI-opinion + follow-up Q&A
  clientSpecificTopics: false,// BlackRock M&A, North Haven, ACI, BN pills

  // ── Blueprint / Deck nice-to-haves ─────────────────────────────────────
  customComponents: false,    // PM-added custom components
  customCharts: false,        // custom chart builder + live preview
  customSlides: false,        // PM-added custom slides
  slideRegen: false,          // per-slide AI regeneration
  slideReorder: false,        // move slides up/down in filmstrip
  printDeck: false            // print (HTML export always stays)
};
