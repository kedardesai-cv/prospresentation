# Alan team meeting notes
Date: 2026-07-02 (filed same day) | Source: handwritten notes, transcribed + clarified with Cecilia

## Raw notes (transcribed)

- SMA 3rd party managed account -> statements + Excel -> flag high fees => SSR (meaning TBD)
- Client that already has a family office
- Statements (fee analysis) -> full Ops folder (managed acct, brokerage, loan)
- Mark as final product
- Many statements but different portfolios
- Screenshot + Modernizer

## Clarified meaning

1. **Broader flagging.** Flag high fees not just on personally managed accounts but also
   third-party managed (SMA) accounts. "SSR" = TBD -- follow up with Alan's team.
2. **Family-office alert.** PM should be made aware when another family office is already
   involved with the prospect.
3. **Inputs.** Statement (PDF) parsing was tried -- "a no so far." They want to upload the
   fee-analysis Excel directly, not only the CV app data export. Fee analysis should draw
   from the full Ops folder: managed accounts, brokerage, loans.
4. **"Mark as final product" = completion lifecycle.** Once a presentation is completed and
   checked by compliance, marking it completed (a) files it into the database with the rest
   of the data and (b) allows the AI to train on the newest presentation. This is the
   feedback loop that grows the knowledge base.
5. **Multi-statement prospects.** Many statements belonging to different portfolios must be
   handled.
6. **Screenshot + Modernizer** as inputs (details TBD).

## Open questions for Alan's team

- What does SSR stand for / what should happen when a high fee is flagged?
- What exactly is Modernizer and what role do screenshots play?
