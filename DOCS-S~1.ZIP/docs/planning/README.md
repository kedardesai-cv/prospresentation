# Planning documents

Source: coworker's project plan, received 2026-07-02. Files arrived with shuffled
names; renamed here so filename matches content.

- project-manifest.json ......... project overview, 3 workstreams, interfaces, milestones
- moscow-requirements.json ...... MoSCoW requirement list (M/S/C/W items)
- shared-data-schema.json ....... validated_portfolio.json contract (WS1 output -> WS2/WS3 input)
- workstream-1-data-pipeline.json  WS1 tasks: Excel parsing + human validation
- workstream-3-narrative-compliance.json  WS3 tasks: narratives + SEC flagging

MISSING: workstream-2-deck-generation.json (WS2 tasks: intro deck, templated
slides, PPTX export). The file with that name contained the manifest instead.
Ask for the real one.

DECIDED 2026-07-02: Option A -- the app in dev/ is the official MVP / vertical
slice. Workstreams build into this codebase. See Prototype_Decision_OnePager.pdf.

Decisions reconciled with our baseline (see ../PRD.md):
- Slide reorder: their plan ranks it "should"; we keep it OFF in the baseline
  (decision reaffirmed 2026-07-02). One flag flip in dev/js/00-config.js if needed.
- Adopted into PRD open items: validated_portfolio schema as parser contract,
  human validation gate, SEC compliance pass before export, PPTX export.
